// Runtime configuration injected by entrypoint
window.APP_CONFIG = {
  API_BASE_URL: '__API_BASE_URL__'
};
